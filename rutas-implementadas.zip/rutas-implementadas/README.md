# MyDashboard
Esta aplicación nos servirá para comprender y  practicar características nuevas de Angular

## Nota
Si deseas saltarte la configuración inicial de Tailwind + Rutas + Componentes, pueden ir a la rama
 ```01-rutas-implementadas``` y descargar ese código.

## Comandos Dev

1. Clonar el proyecto
2. Instalar dependencias ```npm install```
3. Ejecutar el proyecto ```ng serve -o```


